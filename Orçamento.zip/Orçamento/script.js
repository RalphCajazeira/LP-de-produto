let budgets = JSON.parse(localStorage.getItem("budgets")) || {};
let currentBudget = null;
let selectedItem = null;
let isSelectingMultiple = false;
let selectedItems = [];

const budgetList = document.getElementById("budget-list");
const itemList = document.getElementById("item-list");
const contextMenu = document.getElementById("context-menu");
const transferMenu = document.getElementById("transfer-menu");
const addItemButton = document.getElementById("add-item-btn");
const itemNameInput = document.getElementById("item-name");
const itemQuantityInput = document.getElementById("item-quantity");

// Load budgets into the list
function loadBudgets() {
  budgetList.innerHTML = "";
  Object.keys(budgets).forEach((key) => {
    const li = document.createElement("li");
    li.className = "budget-item";

    const span = document.createElement("span");
    span.textContent = `Orçamento ${key}`;
    span.style.cursor = "pointer";
    span.addEventListener("click", () => openBudget(key));

    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "Apagar";
    deleteBtn.addEventListener("click", () => deleteBudget(key));

    li.appendChild(span);
    li.appendChild(deleteBtn);
    budgetList.appendChild(li);
  });
}

// Handle create new budget button
document.getElementById("create-budget-btn").addEventListener("click", () => {
  const budgetName = prompt("Digite o nome do novo orçamento:");
  if (!budgetName || !budgetName.trim()) {
    alert("O nome do orçamento não pode estar vazio ou apenas com espaços.");
    return;
  }
  if (budgets[budgetName]) {
    alert("Já existe um orçamento com este nome.");
    return;
  }
  budgets[budgetName] = [];
  localStorage.setItem("budgets", JSON.stringify(budgets));
  openBudget(budgetName);
});

// Open budget for editing
function openBudget(name) {
  currentBudget = name;
  document.getElementById("current-budget-name").textContent = name;
  loadItems();
  document.getElementById("budget-list-screen").style.display = "none";
  document.getElementById("budget-edit-screen").style.display = "block";
}

// Load items
function loadItems() {
  if (!isSelectingMultiple) {
    itemList.innerHTML = "";
    const items = budgets[currentBudget] || [];
    items.forEach((item, index) => {
      const li = document.createElement("li");
      li.textContent = `${item.name} (x${item.quantity})`;
      li.addEventListener("contextmenu", (e) => openContextMenu(e, li, item));
      itemList.appendChild(li);
    });
  } else {
    renderItemsWithCheckbox();
  }
}

// Add item to the current budget
function addItem() {
  const itemName = itemNameInput.value.trim();
  const itemQuantity = parseInt(itemQuantityInput.value, 10);

  if (!itemName || isNaN(itemQuantity) || itemQuantity <= 0) {
    alert(
      "Por favor, insira um nome de item válido e uma quantidade maior que zero."
    );
    return;
  }

  const newItem = { name: itemName, quantity: itemQuantity };
  budgets[currentBudget] = budgets[currentBudget] || [];
  budgets[currentBudget].push(newItem);
  localStorage.setItem("budgets", JSON.stringify(budgets));
  loadItems();

  // Clear inputs
  itemNameInput.value = "";
  itemQuantityInput.value = "";
}

// Enable multiple selection
function enableMultipleSelection() {
  isSelectingMultiple = true;
  selectedItems = [];
  document.getElementById("transfer-actions").style.display = "flex";
  renderItemsWithCheckbox();
}

// Disable multiple selection
function disableMultipleSelection() {
  isSelectingMultiple = false;
  selectedItems = [];
  document.getElementById("transfer-actions").style.display = "none";
  loadItems();
}

// Render items with checkboxes
function renderItemsWithCheckbox() {
  itemList.innerHTML = "";
  const items = budgets[currentBudget] || [];
  items.forEach((item) => {
    const li = document.createElement("li");
    li.classList.add("item-with-checkbox");

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.className = "item-checkbox";
    checkbox.addEventListener("change", (e) => toggleItemSelection(e, item));

    const span = document.createElement("span");
    span.textContent = `${item.name} (x${item.quantity})`;

    li.appendChild(checkbox);
    li.appendChild(span);
    itemList.appendChild(li);
  });
}

// Toggle item selection
function toggleItemSelection(e, item) {
  if (e.target.checked) {
    selectedItems.push(item);
  } else {
    selectedItems = selectedItems.filter((i) => i !== item);
  }
}

// Transfer items to a new budget
document
  .getElementById("create-new-budget-btn")
  .addEventListener("click", () => {
    if (selectedItems.length === 0) {
      alert("Selecione pelo menos um item para transferir.");
      return;
    }
    const newBudgetName = prompt("Digite o nome do novo orçamento:");
    if (!newBudgetName || !newBudgetName.trim()) {
      alert("O nome do orçamento não pode estar vazio ou apenas com espaços.");
      return;
    }
    if (budgets[newBudgetName]) {
      alert("Já existe um orçamento com este nome.");
      return;
    }
    budgets[newBudgetName] = [...selectedItems];
    budgets[currentBudget] = budgets[currentBudget].filter(
      (item) => !selectedItems.includes(item)
    );
    localStorage.setItem("budgets", JSON.stringify(budgets));
    alert(`Itens transferidos para o novo orçamento "${newBudgetName}".`);
    disableMultipleSelection();
  });

// Transfer items to an existing budget
document
  .getElementById("transfer-existing-btn")
  .addEventListener("click", () => {
    if (selectedItems.length === 0) {
      alert("Selecione pelo menos um item para transferir.");
      return;
    }
    const targetBudget = prompt("Digite o nome do orçamento de destino:");
    if (!targetBudget || !budgets[targetBudget]) {
      alert("Orçamento de destino inválido.");
      return;
    }
    budgets[targetBudget] = budgets[targetBudget].concat(selectedItems);
    budgets[currentBudget] = budgets[currentBudget].filter(
      (item) => !selectedItems.includes(item)
    );
    localStorage.setItem("budgets", JSON.stringify(budgets));
    alert(`Itens transferidos para o orçamento "${targetBudget}".`);
    disableMultipleSelection();
  });

// Cancel transfer
document.getElementById("cancel-transfer-btn").addEventListener("click", () => {
  disableMultipleSelection();
});

// Save budget and return to list screen
document.getElementById("save-budget-btn").addEventListener("click", () => {
  localStorage.setItem("budgets", JSON.stringify(budgets));
  document.getElementById("budget-list-screen").style.display = "block";
  document.getElementById("budget-edit-screen").style.display = "none";
  loadBudgets();
});

// Delete a budget
function deleteBudget(name) {
  const confirmDelete = confirm(
    `Tem certeza que deseja apagar o orçamento "${name}"?`
  );
  if (confirmDelete) {
    delete budgets[name];
    localStorage.setItem("budgets", JSON.stringify(budgets));
    loadBudgets();
    alert(`Orçamento "${name}" apagado com sucesso.`);
  }
}

// Open context menu
function openContextMenu(e, li, item) {
  e.preventDefault();
  selectedItem = { li, item };
  contextMenu.style.left = `${e.pageX}px`;
  contextMenu.style.top = `${e.pageY}px`;
  contextMenu.style.display = "block";
}

// Close context menu
document.addEventListener("click", (e) => {
  const isClickInside = contextMenu.contains(e.target);
  if (!isClickInside) {
    contextMenu.style.display = "none";
  }
});

// Handle menu actions
function handleAction(action) {
  if (action === "selecionar-multiplos") {
    enableMultipleSelection();
  }
}

// Show/hide transfer submenu
function showTransferMenu() {
  transferMenu.style.display = "block";
}

function hideTransferMenu() {
  transferMenu.style.display = "none";
}

// Load budgets on page load
loadBudgets();
